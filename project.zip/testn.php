<?php
$b = "abc";

switch ($a) {
    case 'value':
        # code...
        print "aaaaaaaa";
        break;
    
    default:
        # code...
        print "bbbbbbbbb";
        break;
}

print "cccccccccc";

?>
