<?php
namespace Functionalities;

require_once "Std.php";
require_once "reply_telegram.php";
require_once "ShowOnTerminal.php";

use ReplyTelegram\ReplyTelegram;
use Telegram\Stdt\ProcessStdt;
use TerminalTelegram\TerminalTelegram;

class Functionalities {

    private ProcessStdt $Std;
    private string $marking;
    private ReplyTelegram $reply;
    private string|null $response;

    public function __construct($array_obj){
        $this->setMarking($array_obj["marking"]);
        $this->setStd(new ProcessStdt($array_obj));
        $this->setReply(new ReplyTelegram($array_obj));
        $this->DirectionTo();
    }

    private function DirectionTo(){
        
        switch ($this->getMarking()) {
            case '/msg':{
                $this->response = $this->getReply()->reply_to_telegram_message();
                break;
            }

            case '/imgg':{
                $this->response = $this->getReply()->reply_to_telegram_photo();
                break;
            }

            default:{
                print("entrou no defalut\n");
                break;
            }
            print "oi";
        }
        
        # Std ....
        print("ehhdhdhdhdhdhdhdhshdhsududhdhdhd");
        $this->getStd()->delet_link_in_general_chat();
        print "\n".__FILE__."\n";

        if(empty($this->response)){
            $this->response = "por algum motivo, não teve resposta!!";
        }else{
            print("lululululul");
        }
        // TerminalTelegram::initialize($obj);
    }

    /**
     * Gets the value of reply
     *
     * @return ReplyTelegram
     */
    public function getReply(): ReplyTelegram
    {
        return $this->reply;
    }

    /**
     * Sets the value of reply
     *
     * @param ReplyTelegram $reply description
     *
     * @return Functionalities
     */
    public function setReply(ReplyTelegram $reply): Functionalities
    {
        $this->reply = $reply;
        return $this;
    }

    /**
     * Gets the value of Std
     *
     * @return ProcessStdt
     */
    public function getStd(): ProcessStdt
    {
        return $this->Std;
    }

    /**
     * Sets the value of Std
     *
     * @param ProcessStdt $Std description
     *
     * @return Functionalities
     */
    public function setStd(ProcessStdt $Std): Functionalities
    {
        $this->Std = $Std;
        return $this;
    }

    /**
     * Gets the value of marking
     *
     * @return string
     */
    public function getMarking(): string
    {
        return $this->marking;
    }

    /**
     * Sets the value of marking
     *
     * @param string $marking description
     *
     * @return Functionalities
     */
    public function setMarking(string $marking): Functionalities
    {
        $this->marking = $marking;
        return $this;
    }
}
